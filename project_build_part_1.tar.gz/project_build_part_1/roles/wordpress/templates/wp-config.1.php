// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress1');

/** MySQL database username */
define('DB_USER', 'wordpress1');

/** MySQL database password */
define('DB_PASSWORD', 'wordpress1');

/** MySQL hostname */
define('DB_HOST', 's3.infra');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

$table_prefix  = 'wp_';

/* That's all, stop editing! Happy blogging. */
